package com.myriam.curptest.domain

val sexos = arrayListOf(
    Pair("M", "Mujer"),
    Pair("H", "Hombre"),
    Pair("X", "No Binario")
)