package com.almy.curp.ui.form.domain

val generos = arrayListOf(
    Pair("M","Mujer"),
    Pair("H","Hombre"),
    Pair("X","No Binario"),
)