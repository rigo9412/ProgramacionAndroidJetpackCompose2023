package com.almy.curp.data

data class CurpEntity(
    var name: String,
    val middleName: String,
    val lastname: String,
    val birth: String,
    val gender: String,
    val state: String
)