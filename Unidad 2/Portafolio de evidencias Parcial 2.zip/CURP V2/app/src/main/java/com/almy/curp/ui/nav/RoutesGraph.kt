package com.almy.curp.ui.nav

enum class RoutesGraph {
    ROOT,
    MAIN,
    FORM,
    WIZARD
}