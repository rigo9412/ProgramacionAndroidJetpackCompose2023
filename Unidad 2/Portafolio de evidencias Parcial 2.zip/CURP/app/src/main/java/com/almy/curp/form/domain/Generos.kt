package com.almy.curp.form.domain

val generos = arrayListOf(
    Pair("H","Hombre"),
    Pair("M","Mujer"),
    Pair("X","No binario")
)