package com.example.generadorcurp.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)

val green = Color(0xFF13322B)
val greenDark = Color(0xFF0C231E)
val gold = Color(0XFFC09E72)