package com.example.generadorcurp.ui.nav

enum class RoutesGraph {
    ROOT,
    MAIN,
    FORM,
    WIZARD
}