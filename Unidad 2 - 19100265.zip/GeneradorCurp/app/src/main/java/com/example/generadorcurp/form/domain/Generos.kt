package com.example.generadorcurp.form.domain

val generos = arrayListOf(
    "H" to "Hombre",
    "M" to "Mujer",
    "X" to "No binario")