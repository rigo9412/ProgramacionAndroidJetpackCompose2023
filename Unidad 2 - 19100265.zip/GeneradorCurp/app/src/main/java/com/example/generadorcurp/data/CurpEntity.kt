package com.example.generadorcurp.data

data class CurpEntity(
    val nombre: String,
    val primerApellido: String,
    val segundoAppelido: String,
    val fechaNacimiento : String,
    val genero : String,
    val estado : String
)