package com.example.generadorcurp.form.domain

import java.time.format.DateTimeFormatter

val FORMATTER_INPUT = DateTimeFormatter.ofPattern("yyyy-MM-dd")
val FORMATTER_CURP = DateTimeFormatter.ofPattern("yyMMdd")