package com.example.minecraft19100155.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)
val basePink = Color(0xFFEF9A9A)
val nosePink = Color(0xFFFFCDD2)
val nosePinkDark = Color(0xFF884B4A)
val black = Color(0xFF050303)
val creeperBase = Color(0xFF039A03)
val creeperMouth = Color(0xFF096404)