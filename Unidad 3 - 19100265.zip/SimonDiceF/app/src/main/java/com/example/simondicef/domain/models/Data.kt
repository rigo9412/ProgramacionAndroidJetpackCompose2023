package com.example.simondicef.domain.models

data class Data(
    val attributes: Attributes,
    val id: Int
)