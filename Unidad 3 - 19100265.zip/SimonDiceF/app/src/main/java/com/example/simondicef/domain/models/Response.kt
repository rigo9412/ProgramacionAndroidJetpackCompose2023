package com.example.simondicef.domain.models

data class Response(
    val data: List<Data>,
    val meta: Meta
)