package com.example.simondicef.domain.models

data class PostResponse(
    val data: Data,
    val meta: Meta
)