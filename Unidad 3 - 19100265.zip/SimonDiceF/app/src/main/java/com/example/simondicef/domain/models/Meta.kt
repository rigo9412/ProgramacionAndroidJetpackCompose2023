package com.example.simondicef.domain.models

data class Meta(
    val pagination: Pagination
)