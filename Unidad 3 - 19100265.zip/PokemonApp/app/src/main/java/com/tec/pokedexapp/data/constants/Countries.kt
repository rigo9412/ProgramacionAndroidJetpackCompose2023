package com.tec.pokedexapp.data.constants

import java.util.*

val countries = Locale.getISOCountries()