package com.tec.pokedexapp.data.model

class ApiResponse : ArrayList<ApiResponseItem>()