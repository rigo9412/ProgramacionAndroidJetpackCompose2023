package com.tec.pokedexapp.data.constants

import androidx.compose.ui.graphics.Color

var DarkRed = Color(0xFF9C0000)
var BackgroundRed = Color(0xFFDD1B1B)

var YellowAccent = Color(0xFFFFD600)
var IndigoAccent = Color(0xFF6B69DB)